import React from "react";
import ReactDOM from "react-dom/client";
import UnikeAdmin from "./UnikeAdmin";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <UnikeAdmin />
  </React.StrictMode>
);
